class Fuzzer():
    def __init__(self, job, engine, target, options):
        None

    def start(self):
        print 'hello radamsa'